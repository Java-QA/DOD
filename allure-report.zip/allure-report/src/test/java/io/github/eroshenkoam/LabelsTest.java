package io.github.eroshenkoam;

import io.qameta.allure.Allure;
import io.qameta.allure.Description;
import io.qameta.allure.Feature;
import io.qameta.allure.Link;
import io.qameta.allure.Owner;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Story;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class LabelsTest {

    @Test
    @Owner("eroshenkoam")
    @Severity(SeverityLevel.BLOCKER)
    @Link(name = "Тестинг", url = "https://github.com")
    @DisplayName("Проверка создания Issue для авторизованного пользователя")
    @Description(
            "Этот тест нужен для того, чтобы проверить работу создания Issue." +
                    "Здесь проверяется раз, два, три"
    )
    @Feature("Задачи в репозитории")
    @Story("Пользователь должен иметь возможность создать задачу в репозитории")
    public void testAnnotatedLabels() {

    }

    @Test
    public void testDynamicLabels() {
        Allure.label("owner", "eroshenkoam");
        Allure.label("severity", SeverityLevel.CRITICAL.value());
        Allure.feature("Задачи в репозитории");
        Allure.story("Пользователь должен иметь возможность удалить задачу в репозитории");
        Allure.link("Тестинг", "https://github.com");
    }
}
